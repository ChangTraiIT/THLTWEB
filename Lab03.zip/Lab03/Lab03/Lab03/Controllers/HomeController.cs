﻿using System.Diagnostics;
using Lab03.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Linq;

namespace Lab03.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index(int? categoryId)
        {
            // Danh sách sản phẩm giả lập (có thể thay bằng dữ liệu từ Database)
            var products = GetProductList();

            // Lấy danh sách sản phẩm nổi bật (giới hạn 6 sản phẩm)
            ViewBag.FeaturedProducts = products.Where(p => p.IsFeatured).Take(6).ToList();

            // Lọc sản phẩm theo danh mục nếu có categoryId
            if (categoryId.HasValue)
            {
                products = products.Where(p => p.CategoryId == categoryId.Value).ToList();
            }

            return View(products);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        // 🔍 API tìm kiếm sản phẩm theo ký tự đầu tiên
        [HttpGet]
        public IActionResult Search(string term)
        {
            var products = GetProductList();

            var suggestions = products
                .Where(p => p.Name_.StartsWith(term, System.StringComparison.OrdinalIgnoreCase))
                .Select(p => new { id = p.Id, name = p.Name_ }) // Trả về ID & Name
                .ToList();

            return Json(suggestions);
        }

        // 📦 Hàm trả về danh sách sản phẩm (có thể thay bằng Database)
        private List<Product> GetProductList()
        {
            return new List<Product>
            {
                // Tiêm kích
                new Product { Id = 1, Name_ = "F-22 Raptor", Price = 250000000, ImageUrl = "https://upload.wikimedia.org/wikipedia/commons/4/46/Lockheed_Martin_F-22A_Raptor_JSOH.jpg", CategoryId = 1, IsFeatured = true },
                new Product { Id = 2, Name_ = "Su-57 Felon", Price = 35000000, ImageUrl = "https://upload.wikimedia.org/wikipedia/commons/0/0a/Sukhoi_T-50_Beltyukov.jpg", CategoryId = 1, IsFeatured = true },
                new Product { Id = 3, Name_ = "Dassault Rafale", Price = 115000000, ImageUrl = "https://upload.wikimedia.org/wikipedia/commons/6/64/Rafale_-_RIAT_2009_%283751416421%29.jpg", CategoryId = 1 },
                new Product { Id = 4, Name_ = "Eurofighter Typhoon", Price = 125000000, ImageUrl = "https://upload.wikimedia.org/wikipedia/commons/3/3c/RAF_Eurofighter_EF-2000_Typhoon_F2_Lofting-1.jpg", CategoryId = 1 },
                new Product { Id = 5, Name_ = "J-20 Mighty Dragon", Price = 110000000, ImageUrl = "https://upload.wikimedia.org/wikipedia/commons/a/a2/J-20_at_Airshow_China_2016.jpg", CategoryId = 1 },

                // Xe tăng
                new Product { Id = 6, Name_ = "M1 Abrams", Price = 6000000, ImageUrl = "https://upload.wikimedia.org/wikipedia/commons/b/b9/Abrams-transparent.png", CategoryId = 2, IsFeatured = true },
                new Product { Id = 7, Name_ = "T-90", Price = 4500000, ImageUrl = "https://upload.wikimedia.org/wikipedia/commons/f/f2/T-90A_MBT_photo009.jpg", CategoryId = 2, IsFeatured = true },
                new Product { Id = 8, Name_ = "Leopard 2", Price = 7000000, ImageUrl = "https://upload.wikimedia.org/wikipedia/commons/2/24/Leopard_2_A5_der_Bundeswehr.jpg", CategoryId = 2 },
                new Product { Id = 9, Name_ = "Challenger 2", Price = 8000000, ImageUrl = "https://upload.wikimedia.org/wikipedia/commons/3/30/Challenger_2_Main_Battle_Tank_patrolling_outside_Basra%2C_Iraq_MOD_45148325.jpg", CategoryId = 2 },
                new Product { Id = 10, Name_ = "K2 Black Panther", Price = 9000000, ImageUrl = "https://upload.wikimedia.org/wikipedia/commons/8/8d/K2_black_panther3.jpg", CategoryId = 2 },

                // Tàu chiến
                new Product { Id = 11, Name_ = "USS Zumwalt", Price = 4000000000, ImageUrl = "https://upload.wikimedia.org/wikipedia/commons/9/9a/USS_Zumwalt_%28DDG_1000%29.jpg", CategoryId = 3, IsFeatured = true },
                new Product { Id = 12, Name_ = "Type 055", Price = 3500000000, ImageUrl = "https://upload.wikimedia.org/wikipedia/commons/7/7e/PLANS_Nanchang_%28DDG-101%29_20210427.jpg", CategoryId = 3, IsFeatured = true },
                new Product { Id = 13, Name_ = "HMS Queen Elizabeth", Price = 3900000000, ImageUrl = "https://upload.wikimedia.org/wikipedia/commons/8/81/HMS_Queen_Elizabeth_in_Gibraltar_-_2018_%2828386226189%29.jpg", CategoryId = 3 },
                new Product { Id = 14, Name_ = "Admiral Kuznetsov", Price = 2500000000, ImageUrl = "https://upload.wikimedia.org/wikipedia/commons/c/c6/Russian_aircraft_carrier_Kuznetsov.jpg", CategoryId = 3 },
                new Product { Id = 15, Name_ = "USS Nimitz", Price = 4500000000, ImageUrl = "https://upload.wikimedia.org/wikipedia/commons/2/2d/USS_Nimitz_%28CVN-68%29.jpg", CategoryId = 3 }
            };
        }
    }
}
