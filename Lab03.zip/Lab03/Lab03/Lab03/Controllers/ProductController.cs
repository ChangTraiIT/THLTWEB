﻿using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Lab03.Models;
using Lab03.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Hosting; // ✅ Quản lý thư mục ảnh trong wwwroot
using Microsoft.EntityFrameworkCore;
using Lab03.Repository;

namespace Lab03.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductRepository _productRepository;
        private readonly ICategoryRepository _categoryRepository;
        private readonly IWebHostEnvironment _webHostEnvironment; // ✅ Để quản lý thư mục ảnh

        public ProductController(IProductRepository productRepository, ICategoryRepository categoryRepository, IWebHostEnvironment webHostEnvironment)
        {
            _productRepository = productRepository;
            _categoryRepository = categoryRepository;
            _webHostEnvironment = webHostEnvironment; // ✅ Lưu thư mục chứa ảnh
        }

        // 🛠 Thêm sản phẩm
        public async Task<IActionResult> Add()
        {
            var categories = await _categoryRepository.GetAllAsync();
            ViewBag.Categories = new SelectList(categories, "Id", "Name_");
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Add(Product product, IFormFile imageFile)
        {
            if (ModelState.IsValid)
            {
                // ✅ Nếu người dùng tải lên ảnh, lưu ảnh vào thư mục
                if (imageFile != null)
                {
                    product.ImageUrl = await SaveImage(imageFile);
                }

                await _productRepository.AddAsync(product);
                return RedirectToAction(nameof(Index));
            }

            var categories = await _categoryRepository.GetAllAsync();
            ViewBag.Categories = new SelectList(categories, "Id", "Name_");
            return View(product);
        }

        // 🛠 Cập nhật sản phẩm
        public async Task<IActionResult> Update(int id)
        {
            var product = await _productRepository.GetByIdAsync(id);
            if (product == null) return NotFound();

            var categories = await _categoryRepository.GetAllAsync();
            ViewBag.Categories = new SelectList(categories, "Id", "Name_", product.CategoryId);
            return View(product);
        }

        [HttpPost]
        public async Task<IActionResult> Update(int id, Product product, IFormFile imageFile)
        {
            if (id != product.Id) return NotFound();

            if (ModelState.IsValid)
            {
                var existingProduct = await _productRepository.GetByIdAsync(id);
                if (existingProduct == null) return NotFound();

                existingProduct.Name_ = product.Name_;
                existingProduct.Price = product.Price;
                existingProduct.Description_ = product.Description_;
                existingProduct.CategoryId = product.CategoryId;

                // ✅ Nếu có ảnh mới, lưu lại ảnh mới và xóa ảnh cũ
                if (imageFile != null)
                {
                    if (!string.IsNullOrEmpty(existingProduct.ImageUrl))
                    {
                        DeleteImage(existingProduct.ImageUrl);
                    }
                    existingProduct.ImageUrl = await SaveImage(imageFile);
                }

                await _productRepository.UpdateAsync(existingProduct);
                return RedirectToAction(nameof(Index));
            }

            var categories = await _categoryRepository.GetAllAsync();
            ViewBag.Categories = new SelectList(categories, "Id", "Name_", product.CategoryId);
            return View(product);
        }

        // ✅ Hàm lưu ảnh vào thư mục wwwroot/images/
        private async Task<string> SaveImage(IFormFile imageFile)
        {
            string uploadFolder = Path.Combine(_webHostEnvironment.WebRootPath, "images");

            // ✅ Tạo thư mục nếu chưa tồn tại
            if (!Directory.Exists(uploadFolder))
            {
                Directory.CreateDirectory(uploadFolder);
            }

            string uniqueFileName = $"{Guid.NewGuid()}_{Path.GetFileName(imageFile.FileName)}";
            string filePath = Path.Combine(uploadFolder, uniqueFileName);

            using (var fileStream = new FileStream(filePath, FileMode.Create))
            {
                await imageFile.CopyToAsync(fileStream);
            }

            return "/images/" + uniqueFileName; // ✅ Trả về đường dẫn ảnh để hiển thị trên web
        }

        // ✅ Hàm xóa ảnh cũ khi cập nhật
        private void DeleteImage(string imageUrl)
        {
            if (!string.IsNullOrEmpty(imageUrl))
            {
                // ✅ Xử lý đường dẫn ảnh (xóa ký tự `/` đầu nếu có)
                string fileName = imageUrl.TrimStart('/');
                string filePath = Path.Combine(_webHostEnvironment.WebRootPath, fileName);

                if (System.IO.File.Exists(filePath))
                {
                    System.IO.File.Delete(filePath);
                }
            }
        }
    }
}
