﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Lab03.Models
{
    public class Product
    {
        public int Id { get; set; }

        [Required, StringLength(100)]
        public string Name_ { get; set; }

        [Required]
        public decimal Price { get; set; }

        public string? Description_ { get; set; }

        public string? ImageUrl { get; set; }

        [ForeignKey("Category")]
        public int? CategoryId { get; set; }
        public Category? Category { get; set; }

        // ➜ Thêm thuộc tính không lưu trong database để hiển thị tên danh mục
        [NotMapped]
        public string? CategoryName { get; set; }
        [Required]
        public int Quantity { get; set; } // ➜ tồn kho hiện tại

    }
}
