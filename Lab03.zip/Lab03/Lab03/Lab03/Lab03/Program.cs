﻿using Lab03.Models;
using Lab03.Repositories;
using Lab03.Repository;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// ==========================
// C?U HÌNH D?CH V?
// ==========================

// C?u hình DbContext k?t n?i SQL Server
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// C?u hình Identity
builder.Services.AddIdentity<ApplicationUser, IdentityRole>()
    .AddEntityFrameworkStores<ApplicationDbContext>()
    .AddDefaultTokenProviders();

// C?u hình Cookie (???ng d?n login/logout)
builder.Services.ConfigureApplicationCookie(options =>
{
    options.LoginPath = "/Account/Login";
    options.LogoutPath = "/Account/Logout";
    options.AccessDeniedPath = "/Account/AccessDenied";
});

// C?u hình MVC + DI cho Repository
builder.Services.AddControllersWithViews();
builder.Services.AddScoped<IProductRepository, EFProductRepository>();
builder.Services.AddScoped<ICategoryRepository, EFCategoryRepository>();
builder.Services.AddHttpContextAccessor();
// ? Thêm c?u hình Session
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

var app = builder.Build();

// ==========================
// KH?I T?O D? LI?U BAN ??U
// ==========================
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();
    var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();
    await SeedAdminAccount(userManager, roleManager);
}

// ==========================
// PIPELINE X? LÝ HTTP
// ==========================
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseSession();
app.UseRouting();

// ? S? d?ng Session tr??c Authentication


app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();

// ==========================
// HÀM T?O TÀI KHO?N ADMIN
// ==========================
static async Task SeedAdminAccount(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager)
{
    string roleName = "Admin";
    string adminEmail = "admin@gmail.com";
    string adminPassword = "Admin@123";

    // Tạo role Admin nếu chưa có
    if (!await roleManager.RoleExistsAsync(roleName))
    {
        var roleResult = await roleManager.CreateAsync(new IdentityRole(roleName));
        if (!roleResult.Succeeded)
        {
            Console.WriteLine($"Error creating role: {string.Join(", ", roleResult.Errors.Select(e => e.Description))}");
            return;
        }
    }

    // Tìm user
    var existingUser = await userManager.FindByEmailAsync(adminEmail);
    if (existingUser == null)
    {
        // Tạo user nếu chưa có
        var adminUser = new ApplicationUser
        {
            UserName = adminEmail,
            Email = adminEmail,
            FullName = "Admin User"
        };

        var userResult = await userManager.CreateAsync(adminUser, adminPassword);
        if (!userResult.Succeeded)
        {
            Console.WriteLine($"Error creating user: {string.Join(", ", userResult.Errors.Select(e => e.Description))}");
            return;
        }

        existingUser = adminUser;
    }

    // Nếu user chưa có vai trò Admin, thêm vào
    if (!await userManager.IsInRoleAsync(existingUser, roleName))
    {
        var addToRoleResult = await userManager.AddToRoleAsync(existingUser, roleName);
        if (!addToRoleResult.Succeeded)
        {
            Console.WriteLine($"Error adding user to role: {string.Join(", ", addToRoleResult.Errors.Select(e => e.Description))}");
        }
    }

    Console.WriteLine("Admin user created successfully.");
}



