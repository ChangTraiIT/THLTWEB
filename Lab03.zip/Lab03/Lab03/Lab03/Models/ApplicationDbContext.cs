﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Lab03.Models;
namespace Lab03.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) :
        base(options)
        {
        }
        public DbSet<Product> Products { get; set; } = null!;
        public DbSet<Category> Categories { get; set; } = null!;
        public DbSet<ProductImage> ProductImages { get; set; } = null!;
        public DbSet<User> Users { get; set; } = null!;
    }

}