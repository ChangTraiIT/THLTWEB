﻿using Lab03.Models;
using Lab03.Repositories;
using Lab03.Repository;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// ✅ Thêm bộ nhớ cache cho Session
builder.Services.AddDistributedMemoryCache();

// ✅ Cấu hình Session
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30); // Thời gian tồn tại của Session
    options.Cookie.HttpOnly = true; // Tăng bảo mật
    options.Cookie.IsEssential = true; // Đảm bảo Session hoạt động ngay cả khi người dùng tắt cookie không cần thiết
});

// ✅ Thêm dịch vụ MVC
builder.Services.AddControllersWithViews();

// ✅ Cấu hình Database
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

if (string.IsNullOrEmpty(connectionString))
{
    Console.ForegroundColor = ConsoleColor.Red;
    Console.WriteLine("⚠️ LỖI: Chuỗi kết nối Database chưa được cấu hình trong `appsettings.json`.");
    Console.ResetColor();
    throw new Exception("Chưa cấu hình chuỗi kết nối Database.");
}

builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(connectionString));

// ✅ Đăng ký Repository (Dependency Injection)
builder.Services.AddScoped<IProductRepository, EFProductRepository>();
builder.Services.AddScoped<ICategoryRepository, EFCategoryRepository>();

// 🔥 Xây dựng ứng dụng
var app = builder.Build();

// ✅ Xử lý lỗi trong môi trường Production
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

// ✅ Cấu hình Middleware
app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();

// ✅ Kích hoạt Session trước Authentication
app.UseSession();

app.UseAuthentication();
app.UseAuthorization();

// ✅ Định tuyến mặc định
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

// ✅ Chạy ứng dụng
app.Run();
